// const { PrismaClient } = require('@prisma/client');
// const prisma = new PrismaClient();

// module.exports = prisma;

import { PrismaClient } from "@prisma/client";
const prisma = new PrismaClient();

export default prisma;
